chmod 777 bin/main.out
./bin/main.out $1 $2 solved_alarm.bif 118